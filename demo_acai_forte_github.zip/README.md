# Açaí do Forte — Demonstração de Autoatendimento

Demonstração de totem 1080x1920 com:
- Tela de descanso clicável com animação de abertura.
- Cabeçalho usando a arte enviada.
- Cardápio de açaí e sorveteria.
- Categorias na barra lateral.
- Interface inspirada em Liquid Glass.
- Complementos com 3 unidades grátis e cobrança a partir da 4ª.
- Seleção múltipla do mesmo complemento.
- Carrinho.
- Campo de observação.
- Comer aqui / Levar.
- PIX / Cartão / Dinheiro.
- Tela de confirmação.

## Arquivos
- `index.html`
- `assets/cabecalho.png`
- `assets/banner-descanso.jpg`

Para o GitHub Pages, mantenha exatamente essa estrutura de pastas.
